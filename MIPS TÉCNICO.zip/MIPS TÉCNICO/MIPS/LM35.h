int ledRojo = 3;
int ledVerde = 5;
int ledAzul = 6;
int pulsador = 8;
int pinBuzzer = 9;
const int tonos[] = {261, 277, 294, 311, 330, 349, 370, 392, 415, 440, 466, 494};
const int countTonos = 10;
int estado = 1;
int iTono;
int contador;
const long eventTime_Tem = 2000; //delay time
unsigned long previousTime_Tem = 0; 
int x;
unsigned long temptot = 0;

int temperatura();

void temp() {
  contador = 0;
  iTono = 0;
  int sensorValue = temperatura();
  Serial.println(sensorValue);
  delay(1);
  if(temperatura() <= 19 && temperatura() >= 14.5){ //Editar valor máximo de tempertaura
    digitalWrite(ledRojo,0);
    digitalWrite(ledVerde,255);
    digitalWrite(ledAzul,0);
    estado = 1;
  }
  if(temperatura() > 19){ //Editar valor máximo de tempertaura
    digitalWrite(ledRojo,255);
    digitalWrite(ledVerde,0);
    digitalWrite(ledAzul,0);
    while(temperatura() > 19 && estado == 1){//Editar valor máximo de tempertaura
         tone(pinBuzzer, tonos[iTono]);
         delay(1);
         contador++;
         if(iTono >= countTonos){
           iTono = 0;
         }
         if(contador == 1000){
           iTono++;
           contador = 0;
         }
       estado = digitalRead(pulsador);
      }
    noTone(pinBuzzer);
  }
  if(temperatura() < 14.5 ){ //Editar valor mínimo de temperatura
    digitalWrite(ledRojo,0);
    digitalWrite(ledVerde,0);
    digitalWrite(ledAzul,255);
    while(temperatura() < 14.5 &&  estado == 1){//Editar valor mínimo de temperatura
      iTono=10;
         tone(pinBuzzer, tonos[iTono]);
         delay(1);
         contador++;
         if(iTono <= 0){
           iTono = 0;
         }
         if(contador == 1000){
           iTono--;
           contador = 0;
         }
       estado = digitalRead(pulsador);
      }
    noTone(pinBuzzer);
  }
}

int temperatura() {
int x;
unsigned long currentTime = millis(); //assigning the value of mills
unsigned long temptot = 0;
//taking 100 sample and adding
for(x=0; x<100 ; x++)
{
  temptot += analogRead(A0);
  }
float  sensorValue = temptot/100; //calculating average
float voltage = sensorValue * (3300 / 1024); //convert sensor reading into milli volt
float temp = voltage*0.1; //convert milli volt to temperature degree Celsius 
if(currentTime-previousTime_Tem >= eventTime_Tem) //Check for delay time
{
  Serial.print(temp);
  Serial.println("ºC");
  previousTime_Tem = currentTime;
}
return temp;
}
